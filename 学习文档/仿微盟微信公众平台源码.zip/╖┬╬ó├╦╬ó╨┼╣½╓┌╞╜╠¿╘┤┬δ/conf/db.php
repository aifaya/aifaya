<?php
return array (
  'DB_TYPE' => 'mysql',
  'DB_HOST' => 'localhost',
  'DB_PORT' => '3306',
  'DB_NAME' => 'weixin',
  'DB_USER' => 'root',
  'DB_PWD' => '52jscn',
  'DB_PREFIX' => 'tp_',
);

?>
<?php 
return array (
  'email' => 'false',
  'email_server' => '',
  'email_port' => '',
  'email_user' => '',
  'email_pwd' => '',
  'email_form' => 'aaa',
  'reg_email_title' => '注册成功',
  'reg_email_content' => '尊敬的用户{username}:
       感谢您在{time}注册了YiCms微分享系统演示站,现在开始验证邮箱!

请将以下网址复制到浏览器进行验证 {code} 进行验证! ^_^

YiCms微分享系统,分享快乐,快乐每一天!http://www.YiCms.cn',
  'pwd_email_title' => '密码找回',
  'pwd_email_content' => '尊敬的用户{username}:
      这一封是来自远方的信,目的是测试找回您遗失的密码.

请将以下网址复制到浏览器进行验证 {code} 进行验证! ^_^
',
  '__hash__' => 'f4c1412b04ea35f1f967cc6010a8dd6b_f6988cde167d9b46a6e5f0c5a432326e',
);
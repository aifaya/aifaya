<?php 
return array (
  'site_name' => '锦尚中国仿微盟微信公众平台最新版',
  'site_title' => '锦尚中国仿微盟微信公众平台最新版',
  'site_url' => 'http://demo.52jscn.com',
  'site_my' => '锦尚中国仿微盟微信公众平台最新版',
  'ischeckuser' => 'false',
  'ipc' => '',
  'site_qq' => '278869155',
  'baidu_map_api' => 'QXpQ9NaEOoovpVhBcL9pM4Wi',
  'site_email' => '278869155@qq.com',
  'keyword' => '锦尚中国仿微盟微信公众平台最新版',
  'content' => '锦尚中国仿微盟微信公众平台最新版',
  'counts' => '',
  'copyright' => '                        Copyright © 2012-2014 锦尚中国 版权所有',
);
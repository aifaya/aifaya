<?php 
return array (
  'upload_type' => 'local',
  'up_bucket' => '',
  'up_form_api_secret' => '',
  'up_username' => '',
  'up_password' => '',
  'up_domainname' => '',
  'up_exts' => 'jpeg,jpg,png',
  'up_size' => '2048',
  'up_path' => './data/upload',
  'connectnum' => '系统维护中',
);
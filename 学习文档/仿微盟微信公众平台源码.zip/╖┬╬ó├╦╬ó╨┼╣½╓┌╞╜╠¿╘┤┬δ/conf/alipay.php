<?php 
return array (
  'alipay_name' => '',
  'alipay_pid' => '',
  'alipay_key' => '',
);
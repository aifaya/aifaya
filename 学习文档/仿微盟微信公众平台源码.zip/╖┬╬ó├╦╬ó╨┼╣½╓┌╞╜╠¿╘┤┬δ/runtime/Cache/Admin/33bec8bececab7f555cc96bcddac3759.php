<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>后台首页</title>
<link href="<?php echo RES;?>/images/main.css" type="text/css" rel="stylesheet">
<meta http-equiv="x-ua-compatible" content="ie=7" />
</head>
<body style="background:none">
<div class="content">
<div class="box">
	<h3>更新消息</h3>
    <div class="con dcon">
    <div class="update">
    <p>主机支持：购买锦尚数据主机产品免费获得运营维护</p>
    <p>环境支持：PHP+Mysql</p>
    <p>网站语言：UTF-8简体中文</p>
    <p>数据库：MySql</p>
    <p>系统版本： 52jscn-v2.5_UTF8  <a href="javascript:alert('欢迎访问锦尚中国获得更多更新信息')" class="isub">检查更新</a></p>
    </div>
    <ul class="myinfo">
   <li>
     <p class="red">您的程序版本为：多用户微信营销开发系统锦尚中国版</p>
     </li>
   <li><span>[ 授权版本：终身免费 ]</span></li>
	</ul>
    </div>
</div>
<!--/box-->
<div class="box">
	<h3>官方动态</h3>
    <div class="con dcon">
    <div class="kjnav">
    <a href="#">使用帮助</a><a href="#">技术售后</a><a href="#">安装指导</a><a href="#">联系我们</a><a href="#">升级咨询</a>
    </div>
    <ul class="myinfo kjinfo">
   <li class="title">售后服务范围</li>
<li>程序第一次安装指导,或第一次协助安装；</li>
<li>服务时间：早9:00 - 晚22:00 如有疑问请在这个时间段联系我们，周未双休；QQ278869155</li>
<li>请勿修改程序,您的擅自修改出现的任何问题,将不在售后内('可指导')；</li>
<li>如果发现BUG,请及时反馈售后技术,我们尽快修复；</li>
<li>您购买的系统,我们永久提供免费升级服务。</li>
	</ul>
    </div>
</div>

<!--/box-->
</div>
</body>
</html>